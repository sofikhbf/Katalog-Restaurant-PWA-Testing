import RestDbSource from '../../data/restaurantdb-source'
import { createRestaurantItemTemplate } from '../templates/template-creator'

const Home = {
  async render () {
    return `
    <section class="content">
    <div class="latest">
        <h1 tabindex="0">Explore</h1>
        <div class="list" id="explore-restaurant"></div>
    </div>
</section>
      `
  },

  async afterRender () {
    const restaurants = await RestDbSource.Homey()
    const restaurantsContainer = document.querySelector('#explore-restaurant')
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant)
    })
  }
}

export default Home
