import UrlParser from '../../routes/url-parser'
import RestDbSource from '../../data/restaurantdb-source'
import { createRestaurantDetailTemplate } from '../templates/template-creator'
import LikeButtonPresenter from '../../utils/like-button-presenter'
import FavoriteRestaurantIdb from '../../data/favorite-restaurant-idb'

const Detail = {
  async render () {
    return `
    <h2 tabindex="0" class="title">Detail Page</h2>
    <section class="content"></section>
    <div id="likeButtonContainer"></div>
      `
  },

  async afterRender () {
    const url = UrlParser.parseActiveUrlWithoutCombiner()
    const restaurant = await RestDbSource.DETAIL(url.id)
    const restaurantContainer = document.querySelector('.content')
    restaurantContainer.innerHTML += createRestaurantDetailTemplate(restaurant)
    restaurantContainer.classList.add('detail-page')

    LikeButtonPresenter.init({
      likeButtonContainer: document.querySelector('#likeButtonContainer'),
      favoriteRestaurant: FavoriteRestaurantIdb,
      restaurant: {
        id: restaurant.id,
        name: restaurant.name,
        pictureId: restaurant.pictureId,
        description: restaurant.description,
        city: restaurant.city,
        rating: restaurant.rating
      }
    })
  }
}

// eslint-disable-next-line semi
export default Detail;
