const assert = require("assert")
Feature("Liking Restaurant")
Before(({ I }) => {
  I.amOnPage("/#/favorite")
})

Scenario("showing empty liked restaurants", ({ I }) => {
  I.seeElement("#explore-restaurant")
  I.see("Tidak ada restaurant untuk ditampilkan", ".list")
})

Scenario("liking one restaurant", async ({ I }) => {
  I.see("Tidak ada restaurant untuk ditampilkan", ".list")
  I.amOnPage("/")
  I.wait(5)
  I.seeElement(".list_item a")
  const firstResto = locate(".list-item__title a").first()
  const firstRestoTitle = await I.grabTextFrom(firstResto)
  I.click(firstResto)
  I.wait(5)
  I.seeElement("#likeButton")
  I.click("#likeButton")
  I.amOnPage("/#/favorite")
  I.seeElement(".list_item")
  const likedRestoTitle = await I.grabTextFrom(".list-item__title")
  assert.strictEqual(firstRestoTitle, likedRestoTitle)
})
